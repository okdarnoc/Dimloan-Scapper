﻿


Command to install all requirements

pip install -r requirements.txt



or just activate venv file

source venv/bin/activate


If you want do new files. Run the file main.py, but delete other csv files or make copy.]
